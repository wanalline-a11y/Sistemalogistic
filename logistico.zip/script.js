// Função para gerar o QR Code
function gerar() {

  var nome = document.getElementById("nome").value.trim();
  var conteudo = document.getElementById("conteudo").value.trim();

  if (conteudo === "") {
    alert("Digite o código para gerar o QR!");
    return;
  }

  // Exibe textos na etiqueta
  document.getElementById("nomeExibido").innerText = nome;
  document.getElementById("conteudoExibido").innerText = conteudo;

  // Limpa QR antigo
  var qrDiv = document.getElementById("qrcode");
  qrDiv.innerHTML = "";

  // Gera novo QR
  new QRCode(qrDiv, {
    text: conteudo,
    width: 200,
    height: 200,
    colorDark: "#000000",
    colorLight: "#ffffff",
    correctLevel: QRCode.CorrectLevel.H
  });
}



// Função para salvar a etiqueta como imagem
function salvarImagem() {

  // Verifica se biblioteca carregou
  if (typeof html2canvas === "undefined") {
    alert("Erro: Biblioteca html2canvas não carregada.\nVerifique Scripts Externos no CodePen.");
    return;
  }

  var etiqueta = document.getElementById("etiqueta");

  html2canvas(etiqueta, {
    backgroundColor: "#ffffff",
    scale: 3
  }).then(function(canvas) {

    var link = document.createElement("a");
    link.download = "etiqueta_logistica.png";
    link.href = canvas.toDataURL("image/png");
    link.click();

  }).catch(function(error) {

    console.error("Erro ao salvar imagem:", error);
    alert("Erro ao gerar imagem.");

  });
}